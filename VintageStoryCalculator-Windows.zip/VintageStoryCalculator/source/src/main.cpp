#ifndef UNICODE
#define UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define NTDDI_VERSION 0x0A000002
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <commctrl.h>
#include <richedit.h>
#include <uxtheme.h>
#include "calculator.hpp"

namespace {
constexpr COLORREF bg=RGB(23,29,28),fg=RGB(237,240,231),muted=RGB(174,188,178),gold=RGB(215,181,110),panel=RGB(31,40,36);
HINSTANCE instance; HWND window; HFONT font=nullptr,titleFont=nullptr,smallFont=nullptr; HBRUSH background,fieldBrush;
UINT dpi=96; bool ready=false; int page=0; bool english=false; std::vector<HWND> all;
HWND title,subtitle,tabMix,tabHide,itemLabel,itemCombo,amountLabel,amountEdit,solventLabel,solventCombo,preset10,preset20,preset50,adjust,output,footer,about,language,languageLabel;
std::wstring volume=L"10",quantity=L"1"; int recipeIndex=0,hideIndex=0; double suggested=0;
enum { ID_TAB_MIX=100,ID_TAB_HIDE,ID_ITEM,ID_AMOUNT,ID_SOLVENT,ID_10,ID_20,ID_50,ID_ADJUST,ID_ABOUT,ID_OUTPUT,ID_LANGUAGE };
const wchar_t* tr(const wchar_t* ru,const wchar_t* en){return english?en:ru;}
const auto& recipeList(){return english?vs::englishRecipes:vs::recipes;}
const auto& hideList(){return english?vs::englishHides:vs::hides;}
int px(int n){return MulDiv(n,dpi,96);}
std::wstring text(HWND h){int n=GetWindowTextLengthW(h);std::wstring s(n+1,L'\0');GetWindowTextW(h,s.data(),n+1);s.resize(n);return s;}
HWND control(const wchar_t* cls,const wchar_t* label,DWORD style,int id=0,DWORD ex=0){
 HWND h=CreateWindowExW(ex,cls,label,WS_CHILD|WS_VISIBLE|style,0,0,10,10,window,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),instance,nullptr);all.push_back(h);return h;
}
void fonts(){
 HFONT old=font,oldTitle=titleFont,oldSmall=smallFont;
 font=CreateFontW(-px(16),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
 titleFont=CreateFontW(-px(30),0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
 smallFont=CreateFontW(-px(13),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
 for(HWND h:all)SendMessageW(h,WM_SETFONT,reinterpret_cast<WPARAM>(font),TRUE);
 SendMessageW(title,WM_SETFONT,reinterpret_cast<WPARAM>(titleFont),TRUE);SendMessageW(footer,WM_SETFONT,reinterpret_cast<WPARAM>(smallFont),TRUE);
 if(old)DeleteObject(old);if(oldTitle)DeleteObject(oldTitle);if(oldSmall)DeleteObject(oldSmall);
}
void move(HWND h,int x,int y,int w,int height){MoveWindow(h,px(x),px(y),px(std::max(1,w)),px(height),TRUE);}
void layout(){
 if(!ready)return;RECT rect;GetClientRect(window,&rect);int w=MulDiv(rect.right,96,dpi),h=MulDiv(rect.bottom,96,dpi);const bool wide=w>=850;int left=wide?330:w-48;
 move(title,24,18,w-200,44);move(subtitle,24,67,w-275,26);move(languageLabel,w-247,69,87,26);move(language,w-155,65,131,140);move(about,w-155,23,131,32);
 move(tabMix,24,108,220,38);move(tabHide,254,108,220,38);
 move(itemLabel,24,169,left,24);move(itemCombo,24,197,left,300);
 move(amountLabel,24,247,left,24);move(amountEdit,24,275,left,34);
 if(wide){
  move(preset10,24,325,86,32);move(preset20,120,325,86,32);move(preset50,216,325,138,32);move(adjust,24,372,left,38);
  move(solventLabel,24,329,left,24);move(solventCombo,24,358,left,230);
  move(output,380,168,w-404,std::max(120,h-222));
 }else{
  move(preset10,24,325,86,32);move(preset20,120,325,86,32);move(preset50,216,325,138,32);move(adjust,366,325,w-390,32);
  move(solventLabel,24,322,190,24);move(solventCombo,218,316,w-242,230);
  move(output,24,379,w-48,std::max(70,h-426));
 }
 move(footer,24,h-32,w-48,22);InvalidateRect(window,nullptr,TRUE);
}
void setReport(const std::wstring& s){
 SendMessageW(output,WM_SETREDRAW,FALSE,0);SetWindowTextW(output,s.c_str());
 CHARFORMAT2W cf{};cf.cbSize=sizeof(cf);cf.dwMask=CFM_COLOR|CFM_SIZE|CFM_FACE|CFM_BOLD;cf.crTextColor=fg;cf.yHeight=240;wcscpy_s(cf.szFaceName,L"Segoe UI");
 SendMessageW(output,EM_SETCHARFORMAT,SCF_ALL,reinterpret_cast<LPARAM>(&cf));
 PARAFORMAT2 pf{};pf.cbSize=sizeof(pf);pf.dwMask=PFM_SPACEAFTER;pf.dySpaceAfter=50;SendMessageW(output,EM_SETPARAFORMAT,0,reinterpret_cast<LPARAM>(&pf));
 SendMessageW(output,EM_SETSEL,0,static_cast<LPARAM>(s.find(L'\r')));cf.dwMask=CFM_COLOR|CFM_BOLD;cf.crTextColor=gold;cf.dwEffects=CFE_BOLD;SendMessageW(output,EM_SETCHARFORMAT,SCF_SELECTION,reinterpret_cast<LPARAM>(&cf));
 SendMessageW(output,EM_SETSEL,0,0);SendMessageW(output,EM_SCROLL,SB_TOP,0);SendMessageW(output,WM_SETREDRAW,TRUE,0);InvalidateRect(output,nullptr,TRUE);
}
void calculate(){
 if(!ready)return;double value;bool ok=vs::parseNumber(text(amountEdit),value);suggested=0;
 if(page==0){
  const auto& r=recipeList().at(recipeIndex);SetWindowTextW(amountLabel,(std::wstring(tr(L"Объём ",L"Volume of "))+r.liquid+tr(L", л",L", L")).c_str());
  if(!ok||value<=0||value>50)setReport(tr(L"ПРОВЕРЬ ОБЪЁМ\r\n\r\nВведи число больше 0 и не больше 50 литров. Можно использовать точку или запятую.",L"CHECK THE VOLUME\r\n\r\nEnter a number greater than 0 and no more than 50 litres. A decimal point or comma is accepted."));
  else{auto result=vs::calculateMix(r,value);setReport(vs::mixtureReport(r,value,english));if(!result.exact)suggested=result.upper;}
 }else{
  if(!ok||value<1||value>10000||std::floor(value)!=value)setReport(tr(L"ПРОВЕРЬ КОЛИЧЕСТВО\r\n\r\nВведи целое количество шкур от 1 до 10 000.",L"CHECK THE QUANTITY\r\n\r\nEnter a whole number of hides from 1 to 10,000."));
  else setReport(vs::hideReport(hideList().at(hideIndex),static_cast<int>(value),SendMessageW(solventCombo,CB_GETCURSEL,0,0)==1,english));
 }
 ShowWindow(adjust,page==0&&suggested>0?SW_SHOW:SW_HIDE);if(suggested>0)SetWindowTextW(adjust,(std::wstring(tr(L"Поставить ",L"Set "))+vs::fmt(suggested,english)+tr(L" л",L" L")).c_str());
}
void selectPage(int next){
 if(ready){if(page==0)volume=text(amountEdit);else quantity=text(amountEdit);}page=next;ready=false;
 SetWindowTextW(tabMix,page==0?tr(L"●  Смеси в бочке",L"●  Barrel mixtures"):tr(L"Смеси в бочке",L"Barrel mixtures"));SetWindowTextW(tabHide,page==1?tr(L"●  Обработка шкур",L"●  Hide processing"):tr(L"Обработка шкур",L"Hide processing"));
 SetWindowTextW(itemLabel,page==0?tr(L"Смесь",L"Mixture"):tr(L"Размер или вид шкуры",L"Hide size or species"));SetWindowTextW(amountLabel,page==0?tr(L"Объём воды, л",L"Water volume, L"):tr(L"Количество шкур, шт.",L"Number of hides"));
 SendMessageW(itemCombo,CB_RESETCONTENT,0,0);
 if(page==0){for(const auto& r:recipeList())SendMessageW(itemCombo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(r.name));}
 else{for(const auto& h:hideList())SendMessageW(itemCombo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(h.name));}
 SendMessageW(itemCombo,CB_SETCURSEL,page==0?recipeIndex:hideIndex,0);SetWindowTextW(amountEdit,(page==0?volume:quantity).c_str());
 for(HWND h:{preset10,preset20,preset50})ShowWindow(h,page==0?SW_SHOW:SW_HIDE);
 for(HWND h:{solventLabel,solventCombo})ShowWindow(h,page==1?SW_SHOW:SW_HIDE);
 SetWindowTextW(title,tr(L"Бочка и шкуры",L"Barrel & Hides"));
 SetWindowTextW(window,tr(L"Бочка и шкуры — Vintage Story",L"Barrel & Hides — Vintage Story"));
 SetWindowTextW(subtitle,tr(L"Vintage Story · Windows",L"Vintage Story · Windows"));
 SetWindowTextW(about,tr(L"О рецептах",L"About recipes"));SetWindowTextW(languageLabel,tr(L"Язык",L"Language"));
 SetWindowTextW(preset10,tr(L"10 л",L"10 L"));SetWindowTextW(preset20,tr(L"20 л",L"20 L"));SetWindowTextW(preset50,tr(L"50 л · полная",L"50 L · full"));
 SetWindowTextW(solventLabel,tr(L"Для замачивания",L"Soaking solution"));
 const auto solvent=SendMessageW(solventCombo,CB_GETCURSEL,0,0);SendMessageW(solventCombo,CB_RESETCONTENT,0,0);
 SendMessageW(solventCombo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(tr(L"Известковая вода",L"Limewater")));
 SendMessageW(solventCombo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(tr(L"Раствор буры",L"Diluted borax")));SendMessageW(solventCombo,CB_SETCURSEL,solvent<0?0:solvent,0);
 SetWindowTextW(footer,tr(L"Без интернета  ·  Ванильные рецепты  ·  1.0.0",L"Offline  ·  Vanilla recipes  ·  1.0.0"));
 ready=true;calculate();layout();
}
LRESULT CALLBACK proc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
 switch(msg){
 case WM_CREATE:{
  window=h;dpi=GetDpiForWindow(h);background=CreateSolidBrush(bg);fieldBrush=CreateSolidBrush(panel);
  title=control(L"STATIC",L"Бочка и шкуры",SS_LEFT);subtitle=control(L"STATIC",L"Vintage Story · калькулятор для Windows",SS_LEFT);
  about=control(L"BUTTON",L"О рецептах",WS_TABSTOP|BS_PUSHBUTTON,ID_ABOUT);
  tabMix=control(L"BUTTON",L"Смеси в бочке",WS_TABSTOP|BS_PUSHBUTTON,ID_TAB_MIX);tabHide=control(L"BUTTON",L"Обработка шкур",WS_TABSTOP|BS_PUSHBUTTON,ID_TAB_HIDE);
  itemLabel=control(L"STATIC",L"Смесь",SS_LEFT);itemCombo=control(L"COMBOBOX",L"",WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,ID_ITEM);
  amountLabel=control(L"STATIC",L"Объём воды, л",SS_LEFT);amountEdit=control(L"EDIT",L"10",WS_TABSTOP|ES_AUTOHSCROLL,ID_AMOUNT,WS_EX_CLIENTEDGE);SendMessageW(amountEdit,EM_SETLIMITTEXT,24,0);
  preset10=control(L"BUTTON",L"10 л",WS_TABSTOP,ID_10);preset20=control(L"BUTTON",L"20 л",WS_TABSTOP,ID_20);preset50=control(L"BUTTON",L"50 л · полная",WS_TABSTOP,ID_50);adjust=control(L"BUTTON",L"",WS_TABSTOP,ID_ADJUST);
  solventLabel=control(L"STATIC",L"Для замачивания",SS_LEFT);solventCombo=control(L"COMBOBOX",L"",WS_TABSTOP|CBS_DROPDOWNLIST,ID_SOLVENT);
  SendMessageW(solventCombo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"Известковая вода"));SendMessageW(solventCombo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"Раствор буры"));SendMessageW(solventCombo,CB_SETCURSEL,0,0);
  output=control(MSFTEDIT_CLASS,L"",WS_TABSTOP|WS_VSCROLL|ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL,ID_OUTPUT,WS_EX_CLIENTEDGE);SendMessageW(output,EM_SETBKGNDCOLOR,0,panel);SendMessageW(output,EM_SETMARGINS,EC_LEFTMARGIN|EC_RIGHTMARGIN,MAKELPARAM(px(18),px(18)));
  footer=control(L"STATIC",L"Работает без интернета  ·  Ванильные рецепты  ·  1.0.0",SS_LEFT);
  languageLabel=control(L"STATIC",L"Язык",SS_LEFT);
  language=control(L"COMBOBOX",L"",WS_TABSTOP|CBS_DROPDOWNLIST,ID_LANGUAGE);
  SendMessageW(language,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"Русский"));SendMessageW(language,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"English"));SendMessageW(language,CB_SETCURSEL,0,0);
  fonts();selectPage(0);return 0;
 }
 case WM_SIZE:layout();return 0;
 case WM_GETMINMAXINFO:{auto* m=reinterpret_cast<MINMAXINFO*>(lp);m->ptMinTrackSize.x=px(620);m->ptMinTrackSize.y=px(550);return 0;}
 case WM_DPICHANGED:{dpi=HIWORD(wp);fonts();auto* r=reinterpret_cast<RECT*>(lp);SetWindowPos(h,nullptr,r->left,r->top,r->right-r->left,r->bottom-r->top,SWP_NOZORDER|SWP_NOACTIVATE);calculate();layout();return 0;}
 case WM_CTLCOLORSTATIC:{HDC dc=reinterpret_cast<HDC>(wp);SetTextColor(dc,reinterpret_cast<HWND>(lp)==title?gold:muted);SetBkColor(dc,bg);return reinterpret_cast<LRESULT>(background);}
 case WM_CTLCOLOREDIT:case WM_CTLCOLORLISTBOX:{HDC dc=reinterpret_cast<HDC>(wp);SetTextColor(dc,fg);SetBkColor(dc,panel);return reinterpret_cast<LRESULT>(fieldBrush);}
 case WM_ERASEBKGND:{RECT r;GetClientRect(h,&r);FillRect(reinterpret_cast<HDC>(wp),&r,background);return 1;}
 case WM_COMMAND:{const int id=LOWORD(wp),event=HIWORD(wp);if(!ready)return 0;
  if(id==ID_LANGUAGE&&event==CBN_SELCHANGE){english=SendMessageW(language,CB_GETCURSEL,0,0)==1;selectPage(page);return 0;}
  if(id==ID_TAB_MIX||id==ID_TAB_HIDE){selectPage(id==ID_TAB_MIX?0:1);return 0;}
  if(id==ID_AMOUNT&&event==EN_CHANGE){calculate();return 0;}
  if(id==ID_ITEM&&event==CBN_SELCHANGE){auto index=static_cast<int>(SendMessageW(itemCombo,CB_GETCURSEL,0,0));if(index>=0){if(page==0)recipeIndex=index;else hideIndex=index;calculate();}return 0;}
  if(id==ID_SOLVENT&&event==CBN_SELCHANGE){calculate();return 0;}
  if(id==ID_10||id==ID_20||id==ID_50){SetWindowTextW(amountEdit,id==ID_10?L"10":id==ID_20?L"20":L"50");return 0;}
  if(id==ID_ADJUST&&suggested>0){SetWindowTextW(amountEdit,vs::fmt(suggested).c_str());return 0;}
  if(id==ID_ABOUT){MessageBoxW(h,tr(L"Бочка и шкуры · 1.0.0\nНезависимый калькулятор для Vintage Story.\n\nПропорции перенесены из веб-версии. Источники:\nwiki.vintagestory.at/Barrel\nwiki.vintagestory.at/Leather_working\n\nСтатья о коже проверена авторами вики для 1.20.7. Соответствие 1.22.7 отдельно не подтверждено. При отличиях проверь справочник H в игре. Моды могут менять рецепты.\n\nВремя указано в игровых часах и днях. Известь для шкур и негашёная известь для строительства — разные материалы.\n\nПриложение не подключается к интернету и не собирает данные.",L"Barrel & Hides · 1.0.0\nIndependent Vintage Story calculator.\n\nRecipes carried over from the website. Sources:\nwiki.vintagestory.at/Barrel\nwiki.vintagestory.at/Leather_working\n\nThe wiki leatherworking article was verified for 1.20.7. Compatibility with 1.22.7 has not been independently confirmed. Check the in-game handbook (H) if recipes differ. Mods may change recipes.\n\nTimes are in-game hours and days. Lime for hides and quicklime for construction are different materials.\n\nThe application works offline and collects no data."),tr(L"О рецептах",L"About recipes"),MB_OK|MB_ICONINFORMATION);return 0;}
  break;
 }
 case WM_DESTROY:ready=false;PostQuitMessage(0);return 0;
 }return DefWindowProcW(h,msg,wp,lp);
}
}
int WINAPI wWinMain(HINSTANCE app,HINSTANCE,LPWSTR,int show){
 instance=app;HMODULE richEdit=LoadLibraryW(L"Msftedit.dll");if(!richEdit){MessageBoxW(nullptr,L"Не удалось загрузить системный компонент Windows Msftedit.dll.",L"Бочка и шкуры",MB_OK|MB_ICONERROR);return 1;}
 INITCOMMONCONTROLSEX icc{sizeof(icc),ICC_STANDARD_CLASSES};InitCommonControlsEx(&icc);
 WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.lpfnWndProc=proc;wc.hInstance=app;wc.lpszClassName=L"VintageStoryCalculatorNative";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hIcon=LoadIconW(app,MAKEINTRESOURCEW(101));wc.hIconSm=wc.hIcon;
 if(!RegisterClassExW(&wc))return 1;
 dpi=GetDpiForSystem();RECT work;SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);int width=std::min(px(1020),static_cast<int>(work.right-work.left)),height=std::min(px(730),static_cast<int>(work.bottom-work.top));
 HWND h=CreateWindowExW(WS_EX_CONTROLPARENT,wc.lpszClassName,L"Бочка и шкуры — Vintage Story",WS_OVERLAPPEDWINDOW,work.left+(work.right-work.left-width)/2,work.top+(work.bottom-work.top-height)/2,width,height,nullptr,nullptr,app,nullptr);
 if(!h)return 1;ShowWindow(h,show);UpdateWindow(h);MSG message;while(GetMessageW(&message,nullptr,0,0)>0){if(!IsDialogMessageW(h,&message)){TranslateMessage(&message);DispatchMessageW(&message);}}
 DeleteObject(font);DeleteObject(titleFont);DeleteObject(smallFont);DeleteObject(background);DeleteObject(fieldBrush);FreeLibrary(richEdit);return static_cast<int>(message.wParam);
}
