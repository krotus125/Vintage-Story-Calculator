#pragma once
#include <algorithm>
#include <cmath>
#include <cwchar>
#include <cwctype>
#include <iomanip>
#include <locale>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace vs {
struct Recipe { const wchar_t* name; const wchar_t* material; const wchar_t* liquid; double litresPerItem; const wchar_t* note; };
inline const std::vector<Recipe> recipes = {
 {L"Известковая вода",L"Известь",L"воды",1,L"Смешивается сразу. Запечатывать бочку не нужно."},
 {L"Раствор буры",L"Измельчённая бура",L"воды",2.5,L"Смешивается сразу. Нужна измельчённая бура, а не кусок минерала."},
 {L"Слабый танин",L"Брёвна дуба или акации",L"воды",10,L"Запечатай бочку на 24 игровых часа."},
 {L"Крепкий танин",L"Брёвна дуба или акации",L"слабого танина",10,L"Нужен готовый слабый танин. Запечатай бочку на 24 игровых часа."},
 {L"Рассол",L"Соль",L"воды",2,L"Смешивается сразу. Рассол нужен для маринования."},
 {L"Гашёная известь",L"Негашёная известь",L"воды",0.25,L"Для строительства, не для шкур. При большом количестве добавляй материал партиями по вместимости слота."},
 {L"Строительный раствор",L"Песок",L"гашёной извести",1,L"Нужна готовая гашёная известь, не обычная вода."}
};
struct Hide { const wchar_t* name; int soak; int tannin; int leather; int parts; };
inline const std::vector<Hide> hides = {
 {L"Маленькая",2,2,1,1},{L"Средняя",4,4,2,1},{L"Большая",6,6,3,1},
 {L"Огромная (обычная)",10,10,5,1},{L"Малайский медведь / панда",6,20,10,2},
 {L"Чёрный медведь",10,20,10,2},{L"Бурый / белый медведь",10,30,15,3},
 {L"Лиса / песец / енот",2,2,1,1}
};
inline const std::vector<Recipe> englishRecipes = {
 {L"Limewater",L"Lime",L"water",1,L"Mixes instantly. No need to seal the barrel."},
 {L"Diluted borax",L"Powdered borax",L"water",2.5,L"Mixes instantly. Use powdered borax, not a mineral chunk."},
 {L"Weak tannin",L"Oak or acacia logs",L"water",10,L"Seal the barrel for 24 in-game hours."},
 {L"Strong tannin",L"Oak or acacia logs",L"weak tannin",10,L"Use prepared weak tannin. Seal for 24 in-game hours."},
 {L"Brine",L"Salt",L"water",2,L"Mixes instantly. Brine is used for pickling."},
 {L"Slaked lime",L"Quicklime",L"water",0.25,L"For building, not hides. Add large amounts in batches that fit the item slot."},
 {L"Mortar",L"Sand",L"slaked lime",1,L"Use prepared slaked lime, not plain water."}
};
inline const std::vector<Hide> englishHides = {
 {L"Small",2,2,1,1},{L"Medium",4,4,2,1},{L"Large",6,6,3,1},
 {L"Huge (generic)",10,10,5,1},{L"Sun bear / panda",6,20,10,2},
 {L"Black bear",10,20,10,2},{L"Brown / polar bear",10,30,15,3},
 {L"Fox / arctic fox / raccoon",2,2,1,1}
};
inline std::wstring fmt(double value,bool english=false) {
 std::wostringstream s; s.imbue(std::locale::classic()); s<<std::fixed<<std::setprecision(2)<<value;
 auto text=s.str(); while(!text.empty()&&text.back()==L'0')text.pop_back(); if(!text.empty()&&text.back()==L'.')text.pop_back();
 if(!english)std::replace(text.begin(),text.end(),L'.',L','); return text;
}
inline bool parseNumber(std::wstring s, double& value) {
 auto first=s.find_first_not_of(L" \t\r\n"); if(first==std::wstring::npos)return false;
 s=s.substr(first,s.find_last_not_of(L" \t\r\n")-first+1);
 std::replace(s.begin(),s.end(),L',',L'.');
 // Only plain decimal numbers: reject exponent, hex, NaN, infinity and suffixes.
 bool digit=false,point=false;
 for(auto ch:s) {if(ch>=L'0'&&ch<=L'9'){digit=true;continue;}if(ch==L'.'&&!point){point=true;continue;}return false;}
 if(!digit)return false;
 std::wistringstream stream(s); stream.imbue(std::locale::classic()); stream>>value;
 return !stream.fail()&&std::isfinite(value);
}
struct Mix { double amount; bool exact; double lower; double upper; };
inline Mix calculateMix(const Recipe& r,double litres) {
 if(!std::isfinite(litres)||litres<=0||litres>50)throw std::invalid_argument("Volume must be in (0,50]");
 const double amount=litres/r.litresPerItem;
 return {amount,std::abs(amount-std::round(amount))<1e-8,
 std::floor(amount+1e-8)*r.litresPerItem,std::ceil(amount-1e-8)*r.litresPerItem};
}
struct HideResult { int soak,tannin,leather,parts,soakBatches,tanninBatches; };
inline int ceilDiv(int a,int b){return (a+b-1)/b;}
inline HideResult calculateHide(const Hide& h,int count) {
 if(count<1||count>10000)throw std::invalid_argument("Count must be in [1,10000]");
 return {h.soak*count,h.tannin*count,h.leather*count,h.parts*count,
 ceilDiv(count,50/h.soak),ceilDiv(h.parts*count,50/(h.tannin/h.parts))};
}
inline std::wstring mixtureReport(const Recipe& r,double litres,bool english=false) {
 if(english){
 const auto m=calculateMix(r,litres);auto f=[](double v){return fmt(v,true);};
 std::wstring s=m.exact?L"ADD TO THE BARREL\r\n":L"PROPORTIONAL AMOUNT\r\n";
 s+=f(m.amount)+L" items — "+r.material+L"\r\n\r\nFor "+f(litres)+L" L of "+r.liquid+L"\r\nRecipe: "+r.name+L"\r\n\r\n";
 if(!m.exact){s+=L"You cannot add part of an item.\r\nExact batch: "+f(m.upper)+L" L of "+r.liquid+L" + "+f(std::ceil(m.amount))+L" items.\r\n";if(m.lower>0)s+=L"Or: "+f(m.lower)+L" L + "+f(std::floor(m.amount))+L" items.\r\n";s+=L"\r\n";}
 s+=L"Ratio: 1 item per "+f(r.litresPerItem)+L" L of "+r.liquid+L".\r\n\r\n"+r.note+L"\r\n\r\nOne barrel holds 50 litres.";return s;
 }
 const auto m=calculateMix(r,litres);
 std::wstring s=m.exact?L"НУЖНО ДОБАВИТЬ\r\n":L"РАСЧЁТ ПО ПРОПОРЦИИ\r\n";
 s+=fmt(m.amount)+L" шт. — "+r.material+L"\r\n\r\n";
 s+=L"На "+fmt(litres)+L" л "+r.liquid+L"\r\nРецепт: "+r.name+L"\r\n\r\n";
 if(!m.exact){s+=L"Дробную часть предмета добавить нельзя.\r\nТочная партия: "+fmt(m.upper)+L" л "+r.liquid+L" + "+fmt(std::ceil(m.amount))+L" шт.\r\n";
 if(m.lower>0)s+=L"Или: "+fmt(m.lower)+L" л + "+fmt(std::floor(m.amount))+L" шт.\r\n";
 s+=L"\r\n";}
 s+=L"Пропорция: 1 шт. на "+fmt(r.litresPerItem)+L" л "+r.liquid+L".\r\n\r\n"+r.note;
 s+=L"\r\n\r\nОдна бочка вмещает 50 литров."; return s;
}
inline std::wstring hideReport(const Hide& h,int count,bool borax,bool english=false) {
 if(english){
 const auto r=calculateHide(h,count);const int logs=ceilDiv(r.tannin,10);auto f=[](double v){return fmt(v,true);};
 std::wstring s=L"REQUIRED FOR "+f(count)+L" HIDES\r\n\r\n";
 s+=(borax?L"Diluted borax: ":L"Limewater: ")+f(r.soak)+L" L\r\nSoaking — 20 in-game hours\r\n\r\n";
 s+=L"Weak tannin: "+f(r.tannin)+L" L\r\nAfter scraping with a knife — 3 in-game days\r\n\r\n";
 s+=L"Strong tannin: "+f(r.tannin)+L" L\r\nFinishing — 4.5 in-game days\r\n\r\n";
 s+=L"LEATHER OUTPUT: "+f(r.leather)+L" pieces\r\n\r\n";
 s+=L"Batches in a 50 L barrel:\r\nSoaking: "+f(r.soakBatches)+L"; each tanning stage: "+f(r.tanninBatches)+L". You can reuse the barrel.\r\n\r\n";
 if(h.parts>1)s+=L"Scraping yields "+f(r.parts)+L" huge hides. Tannin amounts already account for this.\r\n\r\n";
 if(borax){const auto powder=std::ceil(r.soak/2.5);s+=L"For soaking: "+f(powder)+L" powdered borax + "+f(powder*2.5)+L" L of water. This batch uses "+f(r.soak)+L" L of solution.\r\n\r\n";}
 else s+=L"For soaking: "+f(r.soak)+L" lime + "+f(r.soak)+L" L of water.\r\n\r\n";
 s+=L"MAKING TANNIN\r\nPrepare "+f(20*logs)+L" L of weak tannin; turn "+f(10*logs)+L" L of that into strong tannin. Total: "+f(3*logs)+L" oak or acacia logs. Make batches of at most 50 L. Save any surplus for later hides.\r\n\r\nWeak and strong tannin are separate portions.";return s;
 }
 const auto r=calculateHide(h,count);const int logs=ceilDiv(r.tannin,10);
 std::wstring s=L"РАСХОД НА "+fmt(count)+L" ШТ.\r\n\r\n";
 s+=(borax?L"Раствор буры: ":L"Известковая вода: ")+fmt(r.soak)+L" л\r\nЗамачивание — 20 игровых часов\r\n\r\n";
 s+=L"Слабый танин: "+fmt(r.tannin)+L" л\r\nПосле очистки ножом — 3 игровых дня\r\n\r\n";
 s+=L"Крепкий танин: "+fmt(r.tannin)+L" л\r\nЗавершение — 4,5 игровых дня\r\n\r\n";
 s+=L"ПОЛУЧИТСЯ КОЖИ: "+fmt(r.leather)+L" шт.\r\n\r\n";
 s+=L"Партии в бочке 50 л:\r\nЗамачивание — "+fmt(r.soakBatches)+L"; каждый этап дубления — "+fmt(r.tanninBatches)+L". Бочку можно использовать повторно.\r\n\r\n";
 if(h.parts>1)s+=L"После очистки: "+fmt(r.parts)+L" огромных шкур. Расход танина это уже учитывает.\r\n\r\n";
 if(borax){const auto powder=std::ceil(r.soak/2.5);s+=L"Для замачивания: "+fmt(powder)+L" шт. измельчённой буры + "+fmt(powder*2.5)+L" л воды. Израсходуется "+fmt(r.soak)+L" л раствора.\r\n\r\n";}
 else s+=L"Для замачивания: "+fmt(r.soak)+L" шт. извести + "+fmt(r.soak)+L" л воды.\r\n\r\n";
 s+=L"ТАНИН С НУЛЯ\r\nПриготовь "+fmt(20*logs)+L" л слабого танина; "+fmt(10*logs)+L" л из него преврати в крепкий. Всего "+fmt(3*logs)+L" брёвен дуба или акации. Готовь партиями до 50 л. Излишек сохрани для следующих шкур.\r\n\r\nСлабый и крепкий танин — отдельные порции.";return s;
}
}
