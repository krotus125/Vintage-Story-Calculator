#include "../src/calculator.hpp"
#include <cassert>
#include <iostream>
#include <limits>
using namespace vs;
bool noCyrillic(const std::wstring& s){for(auto c:s)if(c>=0x400&&c<=0x4ff)return false;return true;}
int main(){
 double v=0;
 assert(parseNumber(L" 12,5 ",v)&&v==12.5);assert(parseNumber(L"2.5",v)&&v==2.5);
 for(auto s:{L"",L"-1",L"1x",L"NaN",L"inf",L"1,2,3",L"1e3",L"0xFF"})assert(!parseNumber(s,v));
 assert(calculateMix(recipes[0],12).amount==12);
 assert(calculateMix(recipes[1],50).amount==20);
 auto fraction=calculateMix(recipes[2],12);assert(!fraction.exact&&fraction.lower==10&&fraction.upper==20);
 assert(calculateMix(recipes[4],50).amount==25);
 assert(calculateMix(recipes[5],10).amount==40);
 for(double n:{0.0,-1.0,50.01,std::numeric_limits<double>::infinity()}){bool threw=false;try{calculateMix(recipes[0],n);}catch(const std::invalid_argument&){threw=true;}assert(threw);}
 auto large=calculateHide(hides[2],9);assert(large.soak==54&&large.tannin==54&&large.soakBatches==2&&large.tanninBatches==2);
 auto bear=calculateHide(hides[6],2);assert(bear.soak==20&&bear.tannin==60&&bear.parts==6&&bear.leather==30&&bear.tanninBatches==2);
 for(int count:{0,-1,10001}){bool threw=false;try{calculateHide(hides[0],count);}catch(const std::invalid_argument&){threw=true;}assert(threw);}
 assert(recipes.size()==englishRecipes.size()&&hides.size()==englishHides.size());
 for(size_t i=0;i<recipes.size();++i){assert(recipes[i].litresPerItem==englishRecipes[i].litresPerItem);for(double litres:{0.25,12.0,50.0})assert(noCyrillic(mixtureReport(englishRecipes[i],litres,true)));}
 for(size_t i=0;i<hides.size();++i){auto a=calculateHide(hides[i],27),b=calculateHide(englishHides[i],27);assert(a.soak==b.soak&&a.tannin==b.tannin&&a.leather==b.leather&&a.parts==b.parts);for(bool borax:{false,true})assert(noCyrillic(hideReport(englishHides[i],27,borax,true)));}
 assert(fmt(2.5)==L"2,5"&&fmt(2.5,true)==L"2.5");
 std::cout<<"PASS: parsing, recipes, rounding, barrel capacity, bear hides, validation, RU/EN parity and English reports\n";
}
