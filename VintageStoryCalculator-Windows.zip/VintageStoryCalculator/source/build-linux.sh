#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Put the LLVM-MinGW or MinGW-w64 bin directory on PATH first.
mkdir -p release
x86_64-w64-mingw32-windres -I src src/app.rc -O coff -o release/app-res.o
x86_64-w64-mingw32-g++ -std=c++17 -O2 -Wall -Wextra -municode -mwindows -static src/main.cpp release/app-res.o -o release/VintageStoryCalculator.exe -lcomctl32 -luxtheme -Wl,--nxcompat,--dynamicbase
