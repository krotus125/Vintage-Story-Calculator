@echo off
setlocal
cd /d "%~dp0"
where cl >nul 2>nul
if errorlevel 1 (
 echo Run this from an x64 Native Tools Command Prompt for Visual Studio.
 exit /b 1
)
if not exist release mkdir release
rc /nologo /i src /fo release\app.res src\app.rc
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /utf-8 /O2 /MT src\main.cpp release\app.res /Fe:release\VintageStoryCalculator.exe /link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib comctl32.lib uxtheme.lib
if errorlevel 1 exit /b 1
echo Built release\VintageStoryCalculator.exe
