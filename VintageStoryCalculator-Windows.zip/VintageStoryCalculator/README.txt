БОЧКА И ШКУРЫ / BARREL & HIDES — 1.0.0

ЗАПУСК
1. Распакуй архив полностью в любую папку.
2. Запусти VintageStoryCalculator.exe.
3. Язык выбирается справа сверху: Русский / English.

Это самостоятельное нативное приложение для Windows 10 (1607+) / 11 x64.
Установка, Unity, браузер, .NET и подключение к интернету не нужны.
Все рецепты и расчёты находятся внутри приложения.

ФУНКЦИИ
• Семь смесей: известковая вода, раствор буры, слабый и крепкий танин,
  рассол, гашёная известь и строительный раствор.
• Расход жидкостей и выход кожи для обычных и медвежьих шкур.
• Подсказки для точных пропорций из целых предметов.
• Расчёт партий с учётом вместимости бочки 50 литров.
• Русский и английский интерфейс с переключением без перезапуска.
• Ввод с точкой или запятой, управление клавишей Tab.
• Результат можно выделить и скопировать через Ctrl+C.

ПРОВЕРКИ
Расчёты, округление, неверный ввод, медвежьи шкуры, вместимость бочки
и соответствие двух языков проверены автоматическими тестами.
Файл собран для Windows x64. Проверен формат PE и список зависимостей:
нужны только системные компоненты Windows.
Запуск интерфейса на настоящей Windows в этой среде не проверялся.
Приложение не подписано сертификатом издателя.

РЕЦЕПТЫ
Перенесены из созданной ранее веб-версии. Источники:
https://wiki.vintagestory.at/Barrel
https://wiki.vintagestory.at/Leather_working
Статья о коже проверена авторами вики для 1.20.7; соответствие 1.22.7
отдельно не подтверждено. Если есть отличия, ориентируйся на справочник H
в игре. Моды могут менять рецепты. Время указано в игровых часах и днях.

ИСХОДНЫЙ КОД
Папка source содержит C++17/Win32, ресурсы и тесты.
Для повторной сборки в Windows нужны Visual Studio Build Tools с компонентом
Desktop development with C++, Windows SDK. Открой x64 Native Tools Command
Prompt, перейди в source и запусти build-windows.cmd.
Приложение не требует средств разработки на компьютере пользователя.

ENGLISH
Extract the ZIP and run VintageStoryCalculator.exe.
Select English in the top-right language list.
Standalone native Windows 10 (1607+) / 11 x64 app; no installation, Unity,
browser, .NET or internet connection is required.
Calculations and translations have automated tests. The Windows executable
was cross-compiled and its dependencies inspected, but its GUI has not been
run on a real Windows system here. The executable is not publisher-signed.
Recipes were carried over from the website; see the in-app About recipes
button for version caveats and sources. Source code and build scripts are included.
